(setq n 0)
(defun main ()
  (setf n 4)
  (if (= (mod n 2) 0)
    (progn
      (print "par")
    )
    (progn
      (print "impar")
    ))
  (setf n 7)
  (if (= (mod n 2) 0)
    (progn
      (print "par")
    )
    (progn
      (print "impar")
    ))
)
(main)
