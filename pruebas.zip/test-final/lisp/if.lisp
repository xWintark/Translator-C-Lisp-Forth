(setq x 0)
(defun main ()
  (setf x 7)
  (if (> x 5)
    (progn
      (print "mayor que 5")
    ))
  (if (< x 10)
    (progn
      (print "menor que 10")
    ))
)
(main)
