(setq a 0)
(setq b 0)
(defun main ()
  (setf a 1)
  (setf b 0)
  (if (or a b)
    (progn
      (print "al menos uno verdadero")
    ))
  (if (and a b)
    (progn
      (print "ambos verdaderos")
    )
    (progn
      (print "no ambos verdaderos")
    ))
  (if (not b)
    (progn
      (print "b es falso")
    ))
)
(main)
