(setq a 0)
(setq b 0)
(defun main ()
  (setf a 5)
  (setf b 3)
  (if (> a b)
    (progn
      (print "mayor")
    ))
  (if (< b a)
    (progn
      (print "menor")
    ))
  (if (/= a b)
    (progn
      (print "distinto")
    ))
  (if (= a a)
    (progn
      (print "igual a si mismo")
    ))
  (if (<= b a)
    (progn
      (print "menor o igual")
    ))
  (if (>= a b)
    (progn
      (print "mayor o igual")
    ))
)
(main)
