#include <stdio.h>

int a ;
int b ;
int c ;

main ()
{
    a = 1 ;
    b = 0 ;
    c = 1 ;

    if (a && c)  { puts ("and verdadero") ; }
    if (a && b)  { puts ("and falso") ; }
    if (a || b)  { puts ("or verdadero") ; }
    if (!b)      { puts ("not b") ; }
    if (!a)      { puts ("not a") ; }
}

//@ (main)
