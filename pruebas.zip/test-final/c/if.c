#include <stdio.h>

main ()
{
    int x ;

    x = 10 ;
    if (x > 5) {
        puts ("mayor que 5") ;
    }
    if (x < 20) {
        puts ("menor que 20") ;
    }
}

//@ (main)
