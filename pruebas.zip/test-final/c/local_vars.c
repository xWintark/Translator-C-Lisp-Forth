#include <stdio.h>

main ()
{
    int i ;
    int j = 5 ;

    i = j + 1 ;
    printf ("%d %s %d", i, " ", j) ;
    puts ("") ;
}

//@ (main)
