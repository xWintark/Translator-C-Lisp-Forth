#include <stdio.h>

int v [10] ;
int m ;

main ()
{
    int i ;

    m = 10 ;
    i = 0 ;
    while (i < m) {
        v [i] = i * i ;
        i = i + 1 ;
    }

    i = 0 ;
    while (i < m) {
        printf ("%d %s %d", i, " -> ", v [i]) ;
        puts ("") ;
        i = i + 1 ;
    }
}

//@ (main)
