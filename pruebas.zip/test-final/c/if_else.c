#include <stdio.h>

main ()
{
    int x ;

    x = 3 ;
    if (x % 2 == 0) {
        puts ("par") ;
    } else {
        puts ("impar") ;
    }

    x = 8 ;
    if (x % 2 == 0) {
        puts ("par") ;
    } else {
        puts ("impar") ;
    }
}

//@ (main)
