#include <stdio.h>

#define INC(x) x=x+1

main ()
{
    int a [8] ;
    int i ;

    for (i = 0 ; i < 8 ; INC(i)) {
        a [i] = i * 2 ;
    }

    for (i = 0 ; i < 8 ; INC(i)) {
        printf ("%d %s %d", i, " -> ", a [i]) ;
        puts ("") ;
    }
}

//@ (main)
