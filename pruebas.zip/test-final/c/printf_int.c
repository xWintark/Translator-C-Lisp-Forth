#include <stdio.h>

int x ;

main ()
{
    x = 42 ;
    printf ("%d", x) ;
    puts ("") ;
}

//@ (main)
