#include <stdio.h>

saluda ()
{
    puts ("Hola desde la funcion") ;
}

despide ()
{
    puts ("Adios desde la funcion") ;
}

main ()
{
    saluda () ;
    saluda () ;
    despide () ;
}

//@ (main)
