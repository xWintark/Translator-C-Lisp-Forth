#include <stdio.h>

int a ;
int b ;

main ()
{
    a = 10 ;
    b = 20 ;
    printf ("%d %s %d", a, " ", b) ;
    puts ("") ;
}

//@ (main)
