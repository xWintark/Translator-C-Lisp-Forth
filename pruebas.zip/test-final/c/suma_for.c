#include <stdio.h>

#define INC(x) x=x+1

int suma ;

main ()
{
    int i ;

    suma = 0 ;
    for (i = 1 ; i <= 100 ; INC(i)) {
        suma = suma + i ;
    }

    printf ("%d", suma) ;
    puts ("") ;
}

//@ (main)
