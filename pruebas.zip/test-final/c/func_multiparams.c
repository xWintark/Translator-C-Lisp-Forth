#include <stdio.h>

maximo (int a, int b, int c)
{
    int m ;

    m = a ;
    if (b > m) {
        m = b ;
    }
    if (c > m) {
        m = c ;
    }
    return m ;
}

minimo (int a, int b)
{
    if (a < b) {
        return a ;
    } else {
        return b ;
    }
}

main ()
{
    int r ;

    r = maximo (3, 7, 5) ;
    printf ("%d", r) ;
    puts ("") ;

    r = maximo (10, 2, 8) ;
    printf ("%d", r) ;
    puts ("") ;

    r = minimo (4, 9) ;
    printf ("%d", r) ;
    puts ("") ;
}

//@ (main)
