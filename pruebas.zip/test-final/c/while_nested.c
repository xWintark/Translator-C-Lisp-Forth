#include <stdio.h>

main ()
{
    int i ;
    int j ;

    i = 1 ;
    while (i <= 3) {
        j = 1 ;
        while (j <= 3) {
            printf ("%d", i * j) ;
            puts (" ") ;
            j = j + 1 ;
        }
        i = i + 1 ;
    }
}

//@ (main)
