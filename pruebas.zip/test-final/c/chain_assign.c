#include <stdio.h>

int a ;
int b ;
int c ;

main ()
{
    a = b = c = 7 ;
    printf ("%d %s %d %s %d", a, " ", b, " ", c) ;
    puts ("") ;

    a = b = 0 ;
    printf ("%d %s %d", a, " ", b) ;
    puts ("") ;
}

//@ (main)
