#include <stdio.h>

#define DEC(x) x=x-1

main ()
{
    int i ;

    for (i = 5 ; i > 0 ; DEC(i)) {
        printf ("%d %s", i, " ") ;
    }
    puts ("") ;
}

//@ (main)
