#include <stdio.h>

main ()
{
    int i ;
    int j ;

    i = 1 ;
    while (i <= 5) {
        j = 1 ;
        while (j <= 5) {
            printf ("%d", i * j) ;
            puts (" ") ;
            j = j + 1 ;
        }
        i = i + 1 ;
    }
}

//@ (main)
