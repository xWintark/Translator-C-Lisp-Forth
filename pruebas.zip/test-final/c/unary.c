#include <stdio.h>

main ()
{
    int x ;
    int y ;

    x = 5 ;
    y = -x ;
    printf ("%d", y) ;
    puts ("") ;

    if (!x) {
        puts ("x es cero") ;
    } else {
        puts ("x no es cero") ;
    }

    x = 0 ;
    if (!x) {
        puts ("x es cero") ;
    }
}

//@ (main)
