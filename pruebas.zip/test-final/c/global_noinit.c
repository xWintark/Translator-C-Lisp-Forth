#include <stdio.h>

int contador ;

main ()
{
    contador = 5 ;
    printf ("%d", contador) ;
    puts ("") ;
}

//@ (main)
