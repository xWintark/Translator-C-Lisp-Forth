#include <stdio.h>

main ()
{
    int n ;

    n = 5 ;
    switch (n) {
        case 1: puts ("uno") ; break ;
        case 2: puts ("dos") ; break ;
        case 3: puts ("tres") ; break ;
        default: puts ("otro") ;
    }

    n = 1 ;
    switch (n) {
        case 1: puts ("uno") ; break ;
        default: puts ("otro") ;
    }
}

//@ (main)
