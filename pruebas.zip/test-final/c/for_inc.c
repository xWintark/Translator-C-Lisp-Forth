#include <stdio.h>

#define INC(x) x=x+1

main ()
{
    int i ;

    for (i = 0 ; i < 5 ; INC(i)) {
        printf ("%d %s", i, " ") ;
    }
    puts ("") ;
}

//@ (main)
