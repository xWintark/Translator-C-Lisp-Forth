#include <stdio.h>

int a ;
int b ;

main ()
{
    a = 5 ;
    b = 3 ;

    if (a == a) { puts ("igual") ; }
    if (a != b) { puts ("distinto") ; }
    if (b < a)  { puts ("menor") ; }
    if (a > b)  { puts ("mayor") ; }
    if (b <= a) { puts ("menor_o_igual") ; }
    if (a >= b) { puts ("mayor_o_igual") ; }
}

//@ (main)
