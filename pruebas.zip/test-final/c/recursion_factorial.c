#include <stdio.h>

factorial (int n)
{
    if (n <= 1) {
        return 1 ;
    } else {
        return n * factorial (n - 1) ;
    }
}

main ()
{
    int r ;
    int i ;

    i = 1 ;
    while (i <= 10) {
        r = factorial (i) ;
        printf ("%d %s %d", i, " -> ", r) ;
        puts ("") ;
        i = i + 1 ;
    }
}

//@ (main)
