#include <stdio.h>

int a, b = 3, c ;

main ()
{
    a = b + 1 ;
    c = a + b ;
    printf ("%d %s %d %s %d", a, " ", b, " ", c) ;
    puts ("") ;
}

//@ (main)
