#include <stdio.h>

int n = 10 ;

main ()
{
    printf ("%d", n) ;
    puts ("") ;
}

//@ (main)
