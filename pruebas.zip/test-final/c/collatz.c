#include <stdio.h>

int n ;

main ()
{
    n = 27 ;

    while (n != 1) {
        printf ("%d %s", n, " ") ;
        if (n % 2 == 0) {
            n = n / 2 ;
        } else {
            n = n * 3 + 1 ;
        }
    }

    printf ("%d", n) ;
    puts ("") ;
}

//@ (main)
