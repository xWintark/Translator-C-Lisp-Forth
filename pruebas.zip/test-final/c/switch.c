#include <stdio.h>

main ()
{
    int n ;

    n = 2 ;
    switch (n) {
        case 1: puts ("uno") ; break ;
        case 2: puts ("dos") ; break ;
        case 3: puts ("tres") ; break ;
    }

    n = 3 ;
    switch (n) {
        case 1: puts ("uno") ; break ;
        case 2: puts ("dos") ; break ;
        case 3: puts ("tres") ; break ;
    }
}

//@ (main)
