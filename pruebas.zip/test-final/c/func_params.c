#include <stdio.h>

suma (int a, int b)
{
    int r ;

    r = a + b ;
    printf ("%d", r) ;
    puts ("") ;
}

multiplica (int x, int y)
{
    printf ("%d", x * y) ;
    puts ("") ;
}

main ()
{
    suma (3, 4) ;
    suma (10, 20) ;
    multiplica (6, 7) ;
}

//@ (main)
