#include <stdio.h>

#define INC(x) x=x+1

fibonacci (int a, int b, int n)
{
    if (n < 2) {
        return b ;
    } else {
        return fibonacci (b, a + b, n - 1) ;
    }
}

main ()
{
    int i ;
    int r ;

    puts ("Sucesion de Fibonacci") ;
    for (i = 0 ; i < 15 ; INC(i)) {
        r = fibonacci (0, 1, i) ;
        printf ("%d %s %d", i, " -> ", r) ;
        puts ("") ;
    }
}

//@ (main)
