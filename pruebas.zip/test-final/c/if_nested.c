#include <stdio.h>

main ()
{
    int x ;

    x = 7 ;
    if (x > 0) {
        if (x > 5) {
            puts ("grande positivo") ;
        } else {
            puts ("pequeno positivo") ;
        }
    } else {
        puts ("no positivo") ;
    }
}

//@ (main)
