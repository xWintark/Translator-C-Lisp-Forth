#include <stdio.h>

main ()
{
    int i ;

    i = 0 ;
    while (i < 5) {
        printf ("%d %s", i, " ") ;
        i = i + 1 ;
    }
    puts ("") ;
}

//@ (main)
