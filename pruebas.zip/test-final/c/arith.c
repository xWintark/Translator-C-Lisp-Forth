#include <stdio.h>
// Comentario de prueba :)))
int a ;
int b ;
int r ;

main ()
{
    a = 10 ;
    b = 3 ;

    r = a + b ;
    printf ("%d %s", r, " ") ;

    r = a - b ;
    printf ("%d %s", r, " ") ;

    r = a * b ;
    printf ("%d %s", r, " ") ;

    r = a / b ;
    printf ("%d %s", r, " ") ;

    r = a % b ;
    printf ("%d", r) ;
    puts ("") ;
}

//@ (main)
