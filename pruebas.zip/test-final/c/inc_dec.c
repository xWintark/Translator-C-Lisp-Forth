#include <stdio.h>

#define INC(x) x=x+1
#define DEC(x) x=x-1

main ()
{
    int i ;

    i = 5 ;
    INC(i) ;
    printf ("%d %s", i, " ") ;

    DEC(i) ;
    DEC(i) ;
    printf ("%d", i) ;
    puts ("") ;
}

//@ (main)
