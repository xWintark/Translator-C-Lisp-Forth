#include <stdio.h>

cuadrado (int n)
{
    return n * n ;
}

doble (int n)
{
    return n + n ;
}

main ()
{
    int r ;

    r = cuadrado (5) ;
    printf ("%d", r) ;
    puts ("") ;

    r = doble (7) ;
    printf ("%d", r) ;
    puts ("") ;

    printf ("%d", cuadrado (3) + doble (4)) ;
    puts ("") ;
}

//@ (main)
